package algebra;

/**
 * 
 * @author LuisIza
 * 
 */
public class Polinomio {

	private double[] coeficientes;

	/**
	 * Constructor.
	 * 
	 */
	public Polinomio() {
		coeficientes = new double[3];
		
	}

	/**
	 * Constructor por parametro int.
	 * 
	 * @param grado
	 */

	public Polinomio(int grado) {
		coeficientes = new double[grado + 1];
		
	}

	// Metodos

	/**
	 * Constructor por parametro double.
	 * 
	 * @param coefs
	 */
	public Polinomio(double[] coefs) {
		coeficientes = coefs;
	}

	/**
	 * 
	 * @return
	 */
	public int getGrado() {
		return 0;
	}

	/**
	 * 
	 * @param x
	 * @return
	 */
	public double evaluar(double x) {

		double acumulador = 0;
		for (int i = 0; i < coeficientes.length; i++) {
			if (i == 0) {
				acumulador = coeficientes[i];
			} else {
				acumulador = acumulador + coeficientes[i] * (Math.pow(x, i));
			}
		}

		return acumulador;
	}

	/**
	 * 
	 * @param p
	 * @return resultado suma de polinomios
	 */
	public Polinomio sumar(Polinomio p) {
		return null;
	}

	public Polinomio resta(Polinomio p) {
		return null;
	}

	public String toString() {
		String msg = ""+ coeficientes[0];
		for (int i = 1; i < coeficientes.length; i++) {
		
				msg = msg + " + " + coeficientes[i] + "x^" + i;
		}
		return msg;
	}

}
