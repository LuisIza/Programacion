package inicio;

/**
 * 
 * @author horabaixa
 *
 */

import algebra.Polinomio;

public class Inicio {

	public static void main(String[] args) {
		Polinomio p1 = new Polinomio();
		System.out.println(p1.toString());
		System.out.println("----------------------------------------------------");
		Polinomio p2 = new Polinomio(4);
		System.out.println(p2.toString());
		
		System.out.println("----------------------------------------------------");
		double poli[] = {2,4,9};
		Polinomio p = new Polinomio (poli);
		System.out.println(p.toString());
		System.out.println("Evaluar : " + p.evaluar(2));
	}

}
