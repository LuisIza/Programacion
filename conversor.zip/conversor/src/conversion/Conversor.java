package conversion;

public class Conversor {
	static final double KM_A_MILLAS = 0.621371;
	static final double MB_A_ATM = 0.000986923;
	static final double CAL_A_JULIOS = 4184;
	
	public Conversor (){
		
	}
	
	public double millas (double km){	
	return km*KM_A_MILLAS;	
	}
	public double km (double millas){
	return millas/KM_A_MILLAS;	
	}
	public double atmosferas (double milibares){
	return milibares * MB_A_ATM;	
	}
	public double milibares (double atmosferas){
	return atmosferas/ MB_A_ATM;	
	}
	public double julios (double calorias){
	return calorias*CAL_A_JULIOS/1000;	
	}
	public double calorias (double julios){
	return julios*1000/CAL_A_JULIOS;	
	}
	
}
