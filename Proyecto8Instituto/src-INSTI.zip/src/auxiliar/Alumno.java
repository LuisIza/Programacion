package auxiliar;
import auxiliar.Grupo;
public class Alumno {
	int numExpediente;
	
	
	
}
