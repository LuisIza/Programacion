package inicio;
import auxiliar.Grupo;
public class Inicio {

	public static void main(String[] args) {
		Grupo g1 = new Grupo (1,"ESO",4,"A");
		g1.leerDatos();
		System.out.println(g1.toString());

	}

}
